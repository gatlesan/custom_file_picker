export declare class AngularFileUploaderService {
    constructor();
}
