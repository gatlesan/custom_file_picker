export declare class AngularFileUploaderModule {
}
